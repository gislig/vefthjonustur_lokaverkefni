namespace Cryptocop.Software.API.Models.Dtos
{
    public class JwtTokenDto
    {
        public int Id { get; set; }
        public bool Blacklisted { get; set; }
    }
}