global using System.Text.Json.Serialization;
global using System.ComponentModel.DataAnnotations;
global using System;
global using System.Collections.Generic;